//Determines whos turn it is: true is green, false is red (soon to be x and o)
//TM
var turn = true;
$(document).ready(function() {
    $("#my_audio").get(0).play(); //This plays the music
    /*Now the parent function of the if statements, which can also have those little method fucntions in them. this means that the if statements will run every time you click something*/
    $('.square').click(function() {
      if (turn === true) {
        /*Adds the green square class and removes all other classes (just in case you need to change, because the red class trumps it every time)*/
        $(this).addClass('highlighted');
        $(this).removeClass('square');
        $(this).removeClass('highlighted2')
        $(this).append('<img src="o.png" alt="O" height="70" width="70"></img>');
        //changes turn so on the next runthrouhg, it will go to else
        turn = false;



      } else {
        /*does the same thing as the above but with the red class instead of the green one being added*/
        $(this).addClass('highlighted2');
        $(this).removeClass('square');
        $(this).removeClass('highlighted')
        $(this).append('<img src="x.png" alt="X" height="65" width="65"></img>');
        //changes it back to true
        turn = true;
      }

	  var rulesStr = $(this).data("rules");	  // This takes the value of data from the HTML and (because computers are stupid), turns it into a big ol string
	  var rulesStrArr = rulesStr.split("|");  /* This takes the big ol string and says "hey, everytime you see one of these |, take the things on either side of it and turn it into an array.
    This gives us 3 arrays, but those three arrays are still made up of strings. This means that instead of the number, its a text representation of the number, we need to fix that.*/

    var rulesArr = []; // A place to put the value of the new array we make

	  for( i in rulesStrArr ) {
		  rulesArr.push( JSON.parse("[" + rulesStrArr[i] + "]") ); /* JSON, or javascript object notation is a weird thing
      that I have no idea what it is or how it works BUT when you have a bunch of strings that need arraying, its what you need
      This for loop says "go throuhg all the elements in the string arrays we just made, use JSON.parse to turn them into individual REAL arrays (of numbers not text)"
      and stick those arrays into another big array. This creates an arrayception kind of deal, because we have arrays inside an array
      */
	  }

    /*The stuff we just did literally just formatted the strings given in 'data-rules' in the HTML file into an array with arrays in it. for example,
    if you click on square 1, code just goes through the data, splits it at the '|' (I chose it because its a good visual) into 3 text arrays, turns those 3 text arrays into
    number arrays, stuffs those 3 new number arrays into one big array and returns [[1,2,3],[1,4,7],[1,5,9]]. thats all we just did, even if it looks complicated
*/

//Despite how cool what we just did looks, its just converting strings into arrays. This down here is the cool part
      for (i in rulesArr) {
        //This for loop runs through the elements in that array we just made
        /*This if statement says if the first, second and third elements in i array (i being the number array the for loop is working on)
        have the class hihglighted, add the class oWins to them. Each square has a number attached to it (if you go to the HTML, you'll see
      that next to each class "square", theres also a number class, 1 through 81 (although while im writing this comment, I think imma change it)). this says
      for the rules array we just made, go through each array in the big array, make each number corespond to a square by slapping a "." in front of it
      (hence the "."+ some array element), and check to see if that has the class associated with having an O in the square. If all three do, then that means someone just got 3 O's in a row!
        */
        if ( $("." + rulesArr[i][0]).hasClass("highlighted") && $("." + rulesArr[i][1]).hasClass("highlighted") && $("." + rulesArr[i][2]).hasClass("highlighted")){
          /*
          $("." + rulesArr[i][0]).addClass("oWins");
          $("." + rulesArr[i][1]).addClass("oWins");
          $("." + rulesArr[i][2]).addClass("oWins");
          */
          $(this).closest('table').addClass("wonBoardO");
          break;
        }else if ( $("." + rulesArr[i][0]).hasClass("highlighted2") && $("." + rulesArr[i][1]).hasClass("highlighted2") && $("." + rulesArr[i][2]).hasClass("highlighted2")) {
          /*
          $("." + rulesArr[i][0]).addClass("xWins");
          $("." + rulesArr[i][1]).addClass("xWins");
          $("." + rulesArr[i][2]).addClass("xWins");
          */

          $(this).closest('table').addClass("wonBoardX");
          break;

        }
      }

    });

});
